PYTHONPATH=`pwd` airflow initdb
PYTHONPATH=`pwd` airflow webserver -p 8080
