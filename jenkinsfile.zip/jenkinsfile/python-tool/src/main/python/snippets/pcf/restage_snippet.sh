cf restage ${APP_NM}
