cf restart ${APP_NM}
