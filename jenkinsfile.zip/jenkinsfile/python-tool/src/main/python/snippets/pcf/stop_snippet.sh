# ---- begin - pcf_stop.sh - source
cf stop ${APP_NM}
# ---- end - pcf_stop.sh - source
