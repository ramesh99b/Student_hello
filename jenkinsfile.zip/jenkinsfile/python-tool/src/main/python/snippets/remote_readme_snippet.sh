# ---- begin - remote_readme_snippet.sh - source %s#
cat "${_target_path}/${_archive_version}/README" >> "${_target_path}/fdeploy.log"
# ---- end - remote_readme_snippet.sh - source
