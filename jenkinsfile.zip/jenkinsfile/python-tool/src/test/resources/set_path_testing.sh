#!/bin/bash

export PATH=${HOME}/.local/bin:${PATH}
which py.test
