#!/bin/bash

while(true); do clear; date; echo; ps -ef | grep 'COMM\|ak751818' | cut -c1-250 | grep -v grep; sleep 2; done