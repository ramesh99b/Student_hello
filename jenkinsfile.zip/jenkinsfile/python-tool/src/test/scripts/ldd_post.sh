
curl -d '{"host": "urh00600.ute.fedex.com", "version": "3.0.0-SNAPSHOT", "queryCmd": "ReferenceCacheGatewayFXG", "level": "L1", "opco": "FXG", "queryHost": "urh00600", "type": "BW", "deployId": "ReferenceCacheGatewayFXG", "artifactId": "ReferenceCacheGatewayFXG"}' \
-H "Content-Type: application/json" -X POST http://irh00600.ute.fedex.com:8090/sefs-dashboard/api/public/query/register
