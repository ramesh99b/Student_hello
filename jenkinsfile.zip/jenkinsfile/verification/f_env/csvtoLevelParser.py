import json

from  csvmapper import FieldMapper, CSVParser
import csvmapper


class csvtoLevelParser(object):
    pass
def __init__():
    pass


csvreport="file.csv"
fileds=('type','user','host','path','number','puname','appname','lvl')
parser = CSVParser(csvreport,FieldMapper(fileds))
data = parser.buildDict()
datalist = []
fdatlist = {}
levels = ["L1","L2","L3","L4"]

    
def csvlvlinfo(level,data):
    for _data in data:
        for ikey,ivalue in _data.iteritems():
            if (ikey == "lvl") and (ivalue == level):
                datalist.append(_data)
    return (datalist)
                
                    

#
sli= []
jsondata = []
L1 = []
L2 = []
L3 = []
L4 = []
for level in levels:
    dat1 = csvlvlinfo(level, data)
    #print dat1
    #my_json_string = json.dumps(dat1, indent=4)
for level in levels:
    for i in dat1:
        if 'lvl' in i.keys():
            if(level == i['lvl']):
                for k,v in i.items():
                    if v == level:
                        del i['lvl']
                        #print i,level
                        if (level == "L1"):
                            #print str(i)
                            L1.append(str(i).replace("'", "\"").replace("\"{", "{"))
                        if (level == "L2"):
                            #print str(i)
                            L2.append(str(i).replace("'", "\"").replace("\"{", "{"))
                        if (level == "L3"):
                            L3.append(str(i).replace("'", "\"").replace("\"\{", "{"))
                        if (level == "L4"):
                            #print str(i)
                            L4.append(str(i).replace("'", "\"").replace("\"{", "{"))
#print L1
#print L2
#print L3
#print L4
str1 =  "[" + ','.join(L1) +"]"
str2 =  "[" + ','.join(L2) +"]"

data = {'L1': json.loads(str1),'L2':json.loads(str2)}
print json.dumps(data,indent=4)

finalstring = ""
data = {}
for lvl in levels:
    print lvl
    finalstring = "[" + ','.join(lvl) +"]"
    print finalstring
    data [l] = json.loads(finalstring)
    print data
    
    
                        
                        
                        
                        #s = "%s" % (str(i))
                        #sli.append(s)
                
                
#print sli
#print i

                
                        
                        
                        
                         
                           
                        
                        #print i.items().get(v)
                            
                        
                        #print str(i)
                        
                        
#                         for _jsondata in jsondata:
#                             if level in _jsondata:
#                                 jsondata.append({level : i})
#                             else:
#                                 print "in else"
#                                 jsondata.append({level : i})
                    #print jsondata
                            
            
            #jsondata.append(data)            
            #print data
            #print  "<><><" + str(jsondata)
                    
            #print json.dumps(jsondata, indent=4)                
#print jsondata
                         
                         
                #sli.append(i)
#data = { level : sli }
#print json.dumps(data, indent=4)

#print sli


        
        
                
    
#print ">?<>>>>>"
#print level
#print sli


    
     
    
#data = { level : sli }
#print json.dumps(data, indent=4)

        
        


    
    
#json_acceptable_string = stlist.replace("'", "\"")
    
    


 

    
         

    
#data = { _level : fdatlist }
#print json.dumps(data, indent=4)
                

# for i in data:
#     for ikey,ivalue in i.iteritems():
#         if (ikey == "lvl") and (ivalue == "L1"):
#             datalist.append(i.items())
# print (datalist)

        
























# def ConvertToJson(csvreport,outfile):
#     
#     fileds=('type','user','host','path','number','puname','appname','lvl')
#     parser = CSVParser(csvreport,FieldMapper(fileds))
#    
#     converter = csvmapper.JSONConverter(parser)
#     d = converter.doConvert(pretty=True)
#     
#     response = json.loads(d)
#     # wrapping the response in meta data 
#     data = { 'opco' : 'FXE','responses' : response }
#     
#     data_string = json.dumps(data,indent=4)
#     with open(outfile,"w") as f:
#         f.write(data_string)
#   
# ConvertToJson('file.csv','file.json')
