class jsonextract(object):
    pass
    
    
def GetType(data):
    for _data in data:
        return dict(_data)['type']
    
def GetId(data):
    for _data in data:
        return dict(_data)['id']
    
def getData(data):
    for _data in data:
        return _data

def GetrtvString(search_key,rtv):
    for __rtv__ in rtv:
        if ((__rtv__['name']) == search_key):
            retkeyvalue = __rtv__['value']
    return retkeyvalue

def getContent(data):
    json_data = getData(data)
    return dict(json_data)['content']

def compName(data):
    compName = []
    contentdata = getContent(data)
    for gav_parms in contentdata:
        for comp in gav_parms:
            if (comp == "gav"):
                Name = gav_parms['gav'].split(":")[1]
                compName = [{u'name': u'comp_Name', u'value': Name}]
        return  compName   
    

def rtv_data(data):
    rtv = {}
    for _data in data:
        if 'rtv' in dict(_data):
            frtv =  dict(_data)['rtv']
        else:
            frtv =  rtv
        return frtv
            
            
        
def checklevel(data,level):
    json_data = getData(data)
    levels = dict(json_data)['levels']
    for _levels in levels:
        _level = _levels["level"]
        if (_level == level):
            return _level
    else:
        return None

def lvlList(data):
    tf = []
    lvllist_data = getData(data)
    levels = dict(lvllist_data)['levels']
    for _levels in levels:
        if 'level' in _levels:
             tf.append(_levels['level'])
    return tf
            #levelList.append()

def lvl_data (data,level):
    json_data = getData(data)
    _lvl_data = ''
    levels = dict(json_data)['levels']
    for _levels in levels:
        _level = _levels["level"]
        if (_level == level):
            _lvl_data = _levels 
    return _lvl_data

def flattern_rtv_data (data,level):
    _lvl = lvl_data(data,level)
    print "-------------------"
    print _lvl
    print "-------------------"
    print "-------------------"
    if 'rtv' in _lvl: 
        print "if loop"
        rtv_lvl = _lvl["rtv"]
        rtv_lvl.extend(compName(data))
        rtv_lvl.extend(rtv_data(data))
    else:
        rtv_lvl = []
        print "else loop"
        rtv_lvl.extend(compName(data))
        rtv_lvl.extend(rtv_data(data))
    return rtv_lvl
def level_targets(data,level):
    _lvl = lvl_data(data,level)
    targets_lvl = _lvl["targets"]
    return targets_lvl


