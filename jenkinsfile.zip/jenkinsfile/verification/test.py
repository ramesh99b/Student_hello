import fnmatch

file = "config.FXE/fxe-be-ShipmentPU_B1.json" 
filepat = "*/fxe-be-*.json"

if fnmatch.fnmatch(file, filepat):
    print "True"
else:
    print "False"

    